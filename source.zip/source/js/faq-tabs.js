const accordions = document.querySelectorAll('.faq__sublist');
const tabs = document.querySelectorAll('.faq__link');

const OPENED_STATE = 'faq__button--more-info';
const CLOSED_STATE = 'faq__button--less-info';
const ACTIVE_ACCORDION = 'faq__sublist--current';
const ACTIVE_CLASS = 'active';

let activeTab = 0;
let content = null;

function setAttributes() {
  tabs.forEach((tab, index) => tab.setAttribute('data-tab', index));
  accordions.forEach((accordion, index) => accordion.setAttribute('data-accordion', index));
}

function findHeightContent(content) {
  content.style.maxHeight = content.classList.contains(ACTIVE_CLASS) ? `${content.scrollHeight}px` : '0';
}

function resetTabs() {
  tabs.forEach(tab => tab.classList.remove(ACTIVE_CLASS));
}

function resetAccordions() {
  accordions.forEach(accordion => accordion.classList.remove(ACTIVE_ACCORDION));
}

function togglesOfContent(tab, index) {
  const accordion = accordions[index];
  if (accordion.dataset.accordion === tab.dataset.tab) {
    const buttons = accordion.querySelectorAll('.faq__button');
    buttons.forEach((button, index) => {
      content = button.nextElementSibling;
      if (index === 0) {
        openedFirstContent(content, button);
      }
    });
  }
}

function openedFirstContent(content, button) {
  content.classList.add(ACTIVE_CLASS);
  button.classList.remove(OPENED_STATE);
  button.classList.add(CLOSED_STATE);
  findHeightContent(content);
}

function toActiveTab(tab, index) {
  tab.classList.add(ACTIVE_CLASS);
  const accordion = accordions[index];
  activeTab = tab.dataset.tab;
  accordion.classList.add(ACTIVE_ACCORDION);
}

export function initTabs() {
  setAttributes();

  tabs.forEach((tab, index) => {
    const accordion = accordions[index];
    if (accordion.dataset.accordion === tab.dataset.tab) {
      const buttons = accordion.querySelectorAll('.faq__button');
      buttons.forEach((button, index) => {
        content = button.nextElementSibling;
        if (index === 0) {
          openedFirstContent(content, button);
        }
        button.addEventListener('click', () => {

          content = button.nextElementSibling;

          if (content.classList.contains(ACTIVE_CLASS)) {
            button.classList.add(OPENED_STATE);
            button.classList.remove(CLOSED_STATE);
            content.classList.remove(ACTIVE_CLASS);
            findHeightContent(content);
          } else {
            content.classList.add(ACTIVE_CLASS);
            button.classList.remove(OPENED_STATE);
            button.classList.add(CLOSED_STATE);
            findHeightContent(content);
          }
        });
      });
    }


    tab.addEventListener('click', (e) => {
      e.preventDefault();
      resetAccordions();
      resetTabs();
      toActiveTab(e.target, index);
      togglesOfContent(e.target, index);
    });
  });
}
