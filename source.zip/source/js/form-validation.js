// const nameInput = document.querySelector('#name');
// const phoneInput = document.querySelector('#phone');

// function validateName() {
//   const namePattern = /^[a-zA-Z\s]+$/;
//   if (!namePattern.test(nameInput.value)) {
//     nameInput.classList.toggle('error');
//   }
//   return true;
// }

// validateName();

// function validatePhone() {
//   const phonePattern = /^\d+$/;
//   if (!phonePattern.test(phoneInput.value)) {
//     alert('Пожалуйста, введите только цифры в поле Телефон');
//     return false;
//   }
//   return true;
// }
